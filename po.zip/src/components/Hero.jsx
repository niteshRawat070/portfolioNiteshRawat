import { HERO_CONTENT } from '../constants';
import aboutMe from '../assets/aboutMe.jpeg';
import { motion } from 'framer-motion';

const container = (delay) => ({
    hidden: { x: -100, opacity: 0 },
    visible: {
        x: 0,
        opacity: 1,
        transition: { duration: 0.5, delay: delay }
    }
});

const Hero = () => {
  return (
    <div className="border-b border-neutral-900 pb-4 m-10 lg:mb-35 flex flex-col lg:flex-row h-auto items-center justify-center sm:flex-row">
        {/* Image section with responsive order */}
        <div className='flex justify-center items-center w-full lg:w-1/2 lg:pr-8 overflow-hidden order-1 lg:order-1'>
            <motion.img
                initial={{ x: -100, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ duration: 1, delay: 1.5 }}
                className='h-auto max-h-[60%] min-h-[200px] w-full object-contain rounded-lg shadow-lg' 
                src={aboutMe}
                alt='profile pic' 
            />
        </div>
        {/* Text section */}
        <div className="w-full flex flex-col lg:w-1/2 order-2 lg:order-2">
            <div className="flex flex-col items-center lg:items-start">
                <motion.h1
                    variants={container(0.5)}
                    initial="hidden"
                    animate="visible"
                    className="pb-4 text-6xl font-thin tracking-tight lg:mt-16 lg:text-8xl">Nitesh Singh Rawat</motion.h1>
                <motion.span 
                    variants={container(1)}
                    initial="hidden"
                    animate="visible"
                    className="bg-gradient-to-r from-pink-300 via-slate-500 to-purple-500 bg-clip-text text-4xl tracking-tight text-transparent">Web Developer and Customer Service</motion.span>
                <motion.p 
                    variants={container(1.5)}
                    initial="hidden"
                    animate="visible"
                    className='my-4 py-6 font-light tracking-tighter leading-relaxed'>{HERO_CONTENT}</motion.p>
            </div>
        </div>
    </div>
  );
}

export default Hero;
